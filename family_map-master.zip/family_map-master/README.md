# family_map
Family map Android app client and server

Fmserver: server for family map app
Fmclient_two: Android client

App generates and displays family information using Google Maps API
